# GitHub経由でAPKを自動ビルドする手順

## 📋 準備

### 1. GitHubアカウント作成
1. https://github.com/ にアクセス
2. 「Sign up」をクリック
3. メールアドレス、パスワードを入力
4. アカウント作成完了

---

## 🚀 APKビルド手順

### ステップ1: 新しいリポジトリ作成

1. GitHubにログイン
2. 右上の「+」→「New repository」をクリック
3. 以下を入力：
   - **Repository name**: `fx-dow-alert`
   - **Public** を選択（無料）
   - 「Create repository」をクリック

### ステップ2: ファイルをアップロード

2つの方法があります：

#### 方法A: ブラウザから直接アップロード（簡単）

1. 作成したリポジトリのページで「uploading an existing file」をクリック
2. `fx-dow-theory-app-ready.zip` を解凍
3. **すべてのファイルとフォルダ**をドラッグ＆ドロップ
   - ⚠️ 注意：ZIPファイルではなく、**中身のファイル**をアップロード
4. 下部の「Commit changes」をクリック

#### 方法B: GitHub Desktop使用（推奨）

1. GitHub Desktopをダウンロード
   - https://desktop.github.com/
2. インストール後、GitHubアカウントでログイン
3. 「File」→「Clone repository」
4. 先ほど作った `fx-dow-alert` を選択
5. ローカルのフォルダにクローン
6. ZIPを解凍した中身をそのフォルダにコピー
7. GitHub Desktopで「Commit」→「Push」

### ステップ3: 自動ビルド開始

1. GitHubのリポジトリページに戻る
2. 上部メニューの「Actions」タブをクリック
3. 「I understand my workflows, go ahead and enable them」をクリック
4. 左側の「Android CI」をクリック
5. 右上の「Run workflow」→「Run workflow」

**ビルド開始！** 5〜10分待ちます。

### ステップ4: APKダウンロード

1. ビルドが完了したら（緑のチェックマーク✅）
2. ビルド結果をクリック
3. 下部の「Artifacts」セクションにある
4. **「fx-dow-alert-apk」**をクリックしてダウンロード

---

## 📱 APKをスマホにインストール

### 1. APKファイルをスマホに転送
- USBケーブルで接続
- または Google Drive / LINE等で送信

### 2. スマホの設定変更
1. 設定 → セキュリティ
2. 「提供元不明のアプリ」を許可
   - または「不明なアプリのインストール」を許可

### 3. APKをタップしてインストール
1. ファイルマネージャーでAPKを開く
2. 「インストール」をタップ
3. 完了！

---

## ⚠️ トラブルシューティング

### ビルドが失敗する場合

1. `.github/workflows/android-build.yml` が正しくアップロードされているか確認
2. `gradlew` ファイルが存在するか確認
3. すべてのファイルが正しくアップロードされているか確認

### ファイル構成確認

リポジトリに以下のファイルが必要：
```
fx-dow-alert/
├── .github/
│   └── workflows/
│       └── android-build.yml
├── app/
│   ├── build.gradle.kts
│   └── src/
├── gradle/
│   └── wrapper/
├── build.gradle.kts
├── settings.gradle.kts
├── gradlew
└── README.md
```

---

## 📞 サポート

問題があれば教えてください！
