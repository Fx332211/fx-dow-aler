package com.fxalert.dowtheory.analyzer

import com.fxalert.dowtheory.model.*
import kotlin.math.abs

class DowTheoryAnalyzer {
    
    private val swingHighs = mutableListOf<SwingPoint>()
    private val swingLows = mutableListOf<SwingPoint>()
    
    /**
     * ダウ理論に基づいて高値・安値更新を検出
     */
    fun analyzeCandles(candles: List<CandleStick>): List<DowTheorySignal> {
        if (candles.size < 50) return emptyList()
        
        val signals = mutableListOf<DowTheorySignal>()
        
        // スイングポイント（高値・安値）を検出
        detectSwingPoints(candles)
        
        // 最新のローソク足をチェック
        val latest = candles.last()
        
        // 高値更新チェック
        checkHighBreak(candles, latest)?.let { signal ->
            signals.add(signal)
        }
        
        // 安値更新チェック
        checkLowBreak(candles, latest)?.let { signal ->
            signals.add(signal)
        }
        
        return signals
    }
    
    /**
     * スイングポイント（高値・安値）を検出
     */
    private fun detectSwingPoints(candles: List<CandleStick>) {
        swingHighs.clear()
        swingLows.clear()
        
        for (i in 2 until candles.size - 2) {
            val current = candles[i]
            
            // スイング高値: 前後2本より高い
            if (isSwingHigh(candles, i)) {
                swingHighs.add(SwingPoint(
                    timestamp = current.timestamp,
                    price = current.high,
                    type = SwingType.HIGH
                ))
            }
            
            // スイング安値: 前後2本より低い
            if (isSwingLow(candles, i)) {
                swingLows.add(SwingPoint(
                    timestamp = current.timestamp,
                    price = current.low,
                    type = SwingType.LOW
                ))
            }
        }
    }
    
    private fun isSwingHigh(candles: List<CandleStick>, index: Int): Boolean {
        val current = candles[index].high
        return current > candles[index - 1].high &&
               current > candles[index - 2].high &&
               current > candles[index + 1].high &&
               current > candles[index + 2].high
    }
    
    private fun isSwingLow(candles: List<CandleStick>, index: Int): Boolean {
        val current = candles[index].low
        return current < candles[index - 1].low &&
               current < candles[index - 2].low &&
               current < candles[index + 1].low &&
               current < candles[index + 2].low
    }
    
    /**
     * 高値更新をチェック
     */
    private fun checkHighBreak(candles: List<CandleStick>, latest: CandleStick): DowTheorySignal? {
        if (swingHighs.isEmpty()) return null
        
        val recentHighs = swingHighs.takeLast(3)
        if (recentHighs.size < 2) return null
        
        val previousHigh = recentHighs[recentHighs.size - 2].price
        
        // 高値更新判定（ヒゲなしの実体で判定）
        if (latest.close > previousHigh && 
            latest.close == latest.high && // ヒゲなし
            latest.close > latest.open) {  // 陽線
            
            // 帯情報を計算
            val band = calculateBand(candles, Direction.UP)
            
            return DowTheorySignal(
                timestamp = latest.timestamp,
                direction = Direction.UP,
                currentPrice = latest.close,
                band = band,
                tf1m = TrendInfo("1m", Trend.UPTREND, true),
                tf5m = TrendInfo("5m", Trend.UPTREND, true), // 仮
                tf15m = TrendInfo("15m", Trend.UPTREND, true), // 仮
                tf1h = TrendInfo("1h", Trend.UPTREND, true) // 仮
            )
        }
        
        return null
    }
    
    /**
     * 安値更新をチェック
     */
    private fun checkLowBreak(candles: List<CandleStick>, latest: CandleStick): DowTheorySignal? {
        if (swingLows.isEmpty()) return null
        
        val recentLows = swingLows.takeLast(3)
        if (recentLows.size < 2) return null
        
        val previousLow = recentLows[recentLows.size - 2].price
        
        // 安値更新判定（ヒゲなしの実体で判定）
        if (latest.close < previousLow &&
            latest.close == latest.low && // ヒゲなし
            latest.close < latest.open) { // 陰線
            
            // 帯情報を計算
            val band = calculateBand(candles, Direction.DOWN)
            
            return DowTheorySignal(
                timestamp = latest.timestamp,
                direction = Direction.DOWN,
                currentPrice = latest.close,
                band = band,
                tf1m = TrendInfo("1m", Trend.DOWNTREND, true),
                tf5m = TrendInfo("5m", Trend.DOWNTREND, true), // 仮
                tf15m = TrendInfo("15m", Trend.DOWNTREND, true), // 仮
                tf1h = TrendInfo("1h", Trend.DOWNTREND, true) // 仮
            )
        }
        
        return null
    }
    
    /**
     * 帯情報を計算
     */
    private fun calculateBand(candles: List<CandleStick>, direction: Direction): Band {
        val recent = candles.takeLast(30)
        
        // もみ合いゾーン（レンジ）を検出
        val rangeCandles = findConsolidationZone(recent)
        
        val rangeHigh = rangeCandles.maxOfOrNull { it.high } ?: recent.last().high
        val rangeLow = rangeCandles.minOfOrNull { it.low } ?: recent.last().low
        
        // 切り返しポイント（勢いよく反転した起点）
        val reversalRate = findReversalPoint(rangeCandles, direction)
        
        // 前回安値/高値
        val previousLow = swingLows.lastOrNull()?.price ?: rangeLow
        val previousHigh = swingHighs.lastOrNull()?.price ?: rangeHigh
        
        // pips差計算（USD/JPYは小数点2桁）
        val pipsDiff = when (direction) {
            Direction.UP -> abs(rangeHigh - previousLow) * 100
            Direction.DOWN -> abs(previousHigh - rangeLow) * 100
        }
        
        return Band(
            rangeHigh = rangeHigh,
            rangeLow = rangeLow,
            reversalRate = reversalRate,
            previousLow = previousLow,
            previousHigh = previousHigh,
            pipsDiff = pipsDiff
        )
    }
    
    /**
     * もみ合いゾーン（レンジ）を検出
     */
    private fun findConsolidationZone(candles: List<CandleStick>): List<CandleStick> {
        if (candles.size < 5) return candles
        
        // 直近の値動きが小さいゾーンを探す
        var consolidationStart = candles.size - 10
        if (consolidationStart < 0) consolidationStart = 0
        
        return candles.subList(consolidationStart, candles.size)
    }
    
    /**
     * 切り返しポイントを検出
     */
    private fun findReversalPoint(candles: List<CandleStick>, direction: Direction): Double {
        if (candles.isEmpty()) return 0.0
        
        return when (direction) {
            Direction.UP -> {
                // 上昇の場合: 最も低い位置から反転した地点
                candles.minByOrNull { it.low }?.low ?: candles.last().low
            }
            Direction.DOWN -> {
                // 下降の場合: 最も高い位置から反転した地点
                candles.maxByOrNull { it.high }?.high ?: candles.last().high
            }
        }
    }
    
    /**
     * マルチタイムフレーム分析
     */
    fun analyzeMultiTimeframe(
        candles1m: List<CandleStick>,
        candles5m: List<CandleStick>,
        candles15m: List<CandleStick>,
        candles1h: List<CandleStick>
    ): Map<String, TrendInfo> {
        return mapOf(
            "1m" to analyzeTrend(candles1m, "1m"),
            "5m" to analyzeTrend(candles5m, "5m"),
            "15m" to analyzeTrend(candles15m, "15m"),
            "1h" to analyzeTrend(candles1h, "1h")
        )
    }
    
    private fun analyzeTrend(candles: List<CandleStick>, timeframe: String): TrendInfo {
        if (candles.size < 20) {
            return TrendInfo(timeframe, Trend.RANGING, false)
        }
        
        val recentHighs = mutableListOf<Double>()
        val recentLows = mutableListOf<Double>()
        
        // 直近のスイングポイントを抽出
        for (i in 2 until candles.size - 2) {
            if (isSwingHigh(candles, i)) {
                recentHighs.add(candles[i].high)
            }
            if (isSwingLow(candles, i)) {
                recentLows.add(candles[i].low)
            }
        }
        
        val trend = when {
            recentHighs.size >= 2 && recentLows.size >= 2 -> {
                val highsRising = recentHighs.takeLast(2)[1] > recentHighs.takeLast(2)[0]
                val lowsRising = recentLows.takeLast(2)[1] > recentLows.takeLast(2)[0]
                
                when {
                    highsRising && lowsRising -> Trend.UPTREND
                    !highsRising && !lowsRising -> Trend.DOWNTREND
                    else -> Trend.RANGING
                }
            }
            else -> Trend.RANGING
        }
        
        return TrendInfo(timeframe, trend, false)
    }
}
