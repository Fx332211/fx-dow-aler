package com.fxalert.dowtheory.model

data class CandleStick(
    val timestamp: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Long = 0
)

data class Band(
    val rangeHigh: Double,      // レンジ上限
    val rangeLow: Double,       // レンジ下限
    val reversalRate: Double,   // 切り返しレート
    val previousLow: Double,    // 前回安値（上昇の場合）
    val previousHigh: Double,   // 前回高値（下降の場合）
    val pipsDiff: Double        // pips差
)

data class DowTheorySignal(
    val timestamp: Long,
    val direction: Direction,   // UP or DOWN
    val currentPrice: Double,
    val band: Band,
    val tf1m: TrendInfo,        // 1分足
    val tf5m: TrendInfo,        // 5分足
    val tf15m: TrendInfo,       // 15分足
    val tf1h: TrendInfo         // 1時間足
)

data class TrendInfo(
    val timeframe: String,
    val trend: Trend,
    val isAligned: Boolean      // 1分足と同方向か
)

enum class Direction {
    UP, DOWN
}

enum class Trend {
    UPTREND,      // 上昇トレンド
    DOWNTREND,    // 下降トレンド
    RANGING       // レンジ
}

data class SwingPoint(
    val timestamp: Long,
    val price: Double,
    val type: SwingType
)

enum class SwingType {
    HIGH,  // 高値
    LOW    // 安値
}
